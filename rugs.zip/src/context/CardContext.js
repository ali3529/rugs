import React from 'react';

const CardContext=React.createContext({
    cardCount:0
})

export default CardContext;