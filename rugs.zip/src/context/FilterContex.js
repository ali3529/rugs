import React from 'react';

const FilterContex=React.createContext({
    filters:''
})

export default FilterContex;