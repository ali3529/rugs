import React from 'react'

function edite() {
  return (
    <div>edite</div>
  )
}

export default edite