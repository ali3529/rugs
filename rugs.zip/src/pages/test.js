import React from 'react'


function test() {


    return (
        <div className='flex flex-col'>
            <span>
            
helow word
             
            </span>
        </div>
    )
}

export default test
